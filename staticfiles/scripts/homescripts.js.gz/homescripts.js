$('#plantas').click(function(){
    $("html, body").animate({ scrollTop: $('#secc-plantas').offset().top });
  });
$('#instalaciones-e').click(function(){
    $("html, body").animate({ scrollTop: $('#secc-inst').offset().top });
});
$('#aire-a').click(function(){
    $("html, body").animate({ scrollTop: $('#secc-aire').offset().top });
});
$('#ups').click(function(){
    $("html, body").animate({ scrollTop: $('#secc-ups').offset().top });
});
$('#reguladores').click(function(){
    $("html, body").animate({ scrollTop: $('#secc-reguladores').offset().top });
});
$('.arrow-top').click(function(){
    $("html, body").animate({ scrollTop: $('#secc-servicios').offset().top });
});
